


	<!-- javascript -->
	<script type="text/javascript" src="../assets/custom/js/jquery-2.2.4.min.js"></script>
	<script type="text/javascript" src="../assets/custom/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../assets/fullcalendar/moment.min.js"></script>
	<script type="text/javascript" src="../assets/fullcalendar/fullcalendar.min.js"></script>
	<script type="text/javascript" src="../assets/datetimepicker/datetimepicker.js"></script>
	<script type="text/javascript" src="../assets/custom/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript" src="../assets/custom/js/bootstrap-table.js"></script>
	<script type="text/javascript" src="../assets/custom/js/lumino.glyphs.js"></script>

	<!-- datatables -->
	<script src="../assets/datatables/js/jquery.dataTables.min.js"></script>

	<!-- databales net -->
	<script src="../assets/datatables_asset/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
	<script src="../assets/datatables_asset/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
	<script src="../assets/datatables_asset/datatables.net-buttons/js/buttons.flash.min.js"></script>
	<script src="../assets/datatables_asset/datatables.net-buttons/js/buttons.html5.min.js"></script>
	<script src="../assets/datatables_asset/datatables.net-buttons/js/buttons.print.min.js"></script>
	<script src="../assets/datatables_asset/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
	<script src="../assets/datatables_asset/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
	<script src="../assets/datatables_asset/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
	<script src="../assets/datatables_asset/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
	<!-- <script src="../assets/datatables_asset/datatables.net-scroller/js/datatables.scroller.min.js"></script> -->
	<script src="../assets/datatables_asset/jszip/dist/jszip.min.js"></script>
	<script src="../assets/datatables_asset/pdfmake/build/pdfmake.min.js"></script>
	<script src="../assets/datatables_asset/pdfmake/build/vfs_fonts.js"></script>

	<!-- select2 -->
	<script type="text/javascript" src="../assets/select/dist/js/select2.min.js"></script>

	<!-- toastr js -->
	<script type="text/javascript" src="../assets/toastr/js/toastr.min.js"></script>

	<!-- jquery ui -->
	<script type="text/javascript" src="../assets/mycustom/js/jquery-ui.min.js"></script>


	<!-- amcharts -->
	<script type="text/javascript" src="../assets/amcharts/amcharts.js"></script>
	<script type="text/javascript" src="../assets/amcharts/serial.js"></script>
	<script type="text/javascript" src="../assets/amcharts/plugins/export/export.min.js"></script>
	<script type="text/javascript" src="../assets/amcharts/themes/light.js"></script>
	<script type="text/javascript" src="../assets/amcharts/pie.js"></script>

	
	<!-- table display -->
	<script type="text/javascript" src="../assets/mycustom/js/table_display.js"></script>
	<script type="text/javascript" src="../assets/mycustom/js/custom.js"></script>
	<script type="text/javascript" src="../assets/mycustom/js/add.js"></script>
	<script type="text/javascript" src="../assets/mycustom/js/edit.js"></script>
	<script type="text/javascript" src="../assets/mycustom/js/chart.js"></script>

	

	<script>
		var a = '<?php echo basename($_SERVER['PHP_SELF']); ?>';

		
		// if(a === 'new.php'){
		// 	console.log('new');
		// }
		// !function ($) {
		// 	$(document).on("click","ul.nav li.parent > a > span.icon", function(){		  
		// 		$(this).find('em:first').toggleClass("glyphicon-minus");	  
		// 	}); 
		// 	$(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		// }(window.jQuery);

		// $(window).on('resize', function () {
		//   if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		// })
		// $(window).on('resize', function () {
		//   if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		// })
	</script>
</body>
</html>