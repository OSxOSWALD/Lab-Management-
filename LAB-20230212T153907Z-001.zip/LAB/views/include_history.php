<li <?php echo (basename($_SERVER['PHP_SELF']) === 'history.php') ? 'class="active"' : 'class=""' ; ?>>
	<a href="history">
		<svg class="glyph stroked clock">
			<use xlink:href="#stroked-clock"/>
		</svg>
		History
	</a>
</li>
